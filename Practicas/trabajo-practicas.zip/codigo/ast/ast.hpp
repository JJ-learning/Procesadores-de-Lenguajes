/*!	
	\file    ast.hpp
	\brief   Declaration of AST class
	\author  
	\date    2018-12-13
	\version 1.0
*/

#ifndef _AST_HPP_
#define _AST_HPP_

#include <iostream>
#include <stdlib.h>
#include <string>
#include <list>
#include <cmath>

#define ERROR_BOUND 1.0e-6 //!< Error bound for the comparison of real numbers.
/*
#define NUMBER	 1
#define BOOL	 2
#define CHAIN	 3
*/

namespace lp
{
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
/*!	
  \class   ExpNode
  \brief   Definition of atributes and methods of ExpNode class
  \warning Abstract class
*/
class ExpNode
{
public:
	/*!	
		\brief   Type of  the expression
		\warning Pure virtual function: must be redefined in the heir classes
		\return  int
		\sa		 print
	*/
	virtual int getType() = 0;

	/*!	
		\brief   Print the expression
		\warning Pure virtual function: must be redefined in the heir classes
		\return  void
		\sa		 evaluate()
	*/
	virtual void print() = 0;

	/*!	
		\brief   Evaluate the expression as NUMBER
		\warning Virtual function: could be redefined in the heir classes
		\return  double
		\sa		 print
	*/
	virtual double evaluateNumber()
	{
		return 0.0;
	}

	/*!	
		\brief   Evaluate the expression as BOOL
		\warning Virtual function: could be redefined in the heir classes
		\return  bool
		\sa		 print
	*/
	virtual bool evaluateBool()
	{
		return false;
	}

	/*!	
		\brief   Evaluate the expression as BOOL
		\warning Virtual function: could be redefined in the heir classes
		\return  bool
		\sa		 print
	*/
	virtual std::string evaluateCadena()
	{
		return "";
	}
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class VariableNode
  \brief Definition of atributes and methods of VariableNode class
  \note  VariableNode Class publicly inherits from ExpNode class
*/
class VariableNode : public ExpNode
{
private:
	std::string _id; //!< Name of the VariableNode

public:
	/*!		
		\brief Constructor of VariableNode
		\param value: double
		\post  A new NumericVariableNode is created with the name of the parameter
		\note  Inline function
	*/
	VariableNode(std::string const &value)
	{
		this->_id = value;
	}

	/*!	
		\brief   Type of the Variable
		\return  int
		\sa		 print
	*/
	int getType();

	/*!
		\brief   Print the Variable
		\return  void
		\sa		 evaluate()
	*/
	void print();

	/*!	
		\brief   Evaluate the Variable as NUMBER
		\return  double
		\sa		 print
	*/
	double evaluateNumber();

	/*!	
		\brief   Evaluate the Variable as BOOL
		\return  bool
		\sa		 print
	*/
	bool evaluateBool();

	/*!	
		\brief   Evaluate the Variable as CHAIN
		\return  bool
		\sa		 print
	*/
	std::string evaluateCadena();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class ConstantNode
  \brief Definition of atributes and methods of ConstantNode class
  \note  ConstantNode Class publicly inherits from ExpNode class
*/
class ConstantNode : public ExpNode
{
private:
	std::string _id; //!< Name of the ConstantNode

public:
	/*!		
		\brief Constructor of ConstantNode
		\param value: double
		\post  A new ConstantNode is created with the name of the parameter
	*/
	ConstantNode(std::string value)
	{
		this->_id = value;
	}

	/*!	
		\brief   Type of the Constant
		\return  int
		\sa		 print
	*/
	int getType();

	/*!
		\brief   Print the Constant
		\return  void
		\sa		 evaluate()
	*/
	void print();

	/*!	
		\brief   Evaluate the Constant as NUMBER
		\return  double
		\sa		 print
	*/
	double evaluateNumber();

	/*!	
		\brief   Evaluate the Constant as BOOL
		\return  bool
		\sa		 print
	*/
	bool evaluateBool();

	/*!	
		\brief   Evaluate the Variable as CHAIN
		\return  bool
		\sa		 print
	*/
	std::string evaluateCadena();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class NumberNode
  \brief Definition of atributes and methods of NumberNode class
  \note  NumberNode Class publicly inherits from ExpNode class
*/
class NumberNode : public ExpNode
{
private:
	double _number; //!< \brief number of the NumberNode

public:
	/*!		
	\brief Constructor of NumberNode
	\param value: double
	\post  A new NumberNode is created with the value of the parameter
	\note  Inline function
*/
	NumberNode(double value)
	{
		this->_number = value;
	}

	/*!	
	\brief   Get the type of the expression: NUMBER
	\return  int
	\sa		 print
	*/
	int getType();

	/*!
		\brief   Print the expression
		\return  void
		\sa		 evaluate()
	*/
	void print();

	/*!	
		\brief   Evaluate the expression
		\return  double
		\sa		 print
	*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class CadenaNode
  \brief Definition of atributes and methods of CadenaNode class
  \note  CadenaNode Class publicly inherits from ExpNode class
*/
class CadenaNode : public ExpNode
{
private:
	std::string _cadena; //!< \brief string of the CadenaNode

public:
	/*!		
	\brief Constructor of CadenaNode
	\param value: string
	\post  A new CadenaNode is created with the value of the parameter
	\note  Inline function
*/
	CadenaNode(std::string value)
	{
		this->_cadena = value;
	}

	/*!	
	\brief   Get the type of the expression: CHAIN
	\return  int
	\sa		 print
	*/
	int getType();

	/*!
		\brief   Print the expression
		\return  void
		\sa		 evaluate()
	*/
	void print();

	/*!	
		\brief   Evaluate the expression
		\return  string
		\sa		 print
	*/
	std::string evaluateCadena();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   UnaryOperatorNode
  \brief   Definition of atributes and methods of UnaryOperatorNode class
  \note    UnaryOperatorNode Class publicly inherits from ExpNode class
  \warning Abstract class, because it does not redefine the print method of ExpNode
*/
class UnaryOperatorNode : public ExpNode
{
protected:
	ExpNode *_exp; //!< Child expression

public:
	/*!		
	\brief Constructor of UnaryOperatorNode links the node to it child,
           and stores the character representation of the operator.
	\param expression: pointer to ExpNode
	\post  A new OperatorNode is created with the parameters
	\note  Inline function
*/
	UnaryOperatorNode(ExpNode *expression)
	{
		this->_exp = expression;
	}

	/*!	
	\brief   Get the type of the child expression
	\return  int
	\sa		 print
	*/
	inline int getType()
	{
		return this->_exp->getType();
	}
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   NumericUnaryOperatorNode
  \brief   Definition of atributes and methods of UnaryOperatorNode class
  \note    UnaryOperatorNode Class publicly inherits from UnaryOperatorNode class
  \warning Abstract class, because it does not redefine the print method of ExpNode
*/
class NumericUnaryOperatorNode : public UnaryOperatorNode
{
public:
	/*!		
	\brief Constructor of NumericUnaryOperatorNode uses UnaryOperatorNode's constructor as member initializer
	\param expression: pointer to ExpNode
	\post  A new NumericUnaryOperatorNode is created with the parameters
	\note  Inline function
*/
	NumericUnaryOperatorNode(ExpNode *expression) : UnaryOperatorNode(expression)
	{
		// Empty
	}

	/*!	
	\brief   Get the type of the child expression
	\return  int
	\sa		 print
	*/
	int getType();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   LogicalUnaryOperatorNode
  \brief   Definition of atributes and methods of UnaryOperatorNode class
  \note    UnaryOperatorNode Class publicly inherits from UnaryOperatorNode class
  \warning Abstract class, because it does not redefine the print method of ExpNode
*/
class LogicalUnaryOperatorNode : public UnaryOperatorNode
{
public:
	/*!		
	\brief Constructor of LogicalUnaryOperatorNode uses UnaryOperatorNode's constructor as member initializer
	\param expression: pointer to ExpNode
	\post  A new NumericUnaryOperatorNode is created with the parameters
	\note  Inline function
*/
	LogicalUnaryOperatorNode(ExpNode *expression) : UnaryOperatorNode(expression)
	{
		// Empty
	}

	/*!	
	\brief   Get the type of the child expression
	\return  int
	\sa		 print
	*/
	int getType();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   UnaryMenosNode
  \brief   Definition of atributes and methods of UnaryMenosNode class
  \note    UnaryMenosNode Class publicly inherits from NumericUnaryOperatorNode class
*/
class UnaryMenosNode : public NumericUnaryOperatorNode
{

public:
	/*!		
	\brief Constructor of UnaryMenosNode uses NumericUnaryOperatorNode's constructor as member initializer.
	\param expression: pointer to ExpNode
	\post  A new UnaryMenosNode is created with the parameter
	\note  Inline function: the NumericUnaryOperatorNode's constructor is used ad member initializer
*/
	UnaryMenosNode(ExpNode *expression) : NumericUnaryOperatorNode(expression)
	{
		// empty
	}

	/*!
	\brief   Print the expression
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the expression
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};

//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

/*!	
  \class   UnaryMasNode
  \brief   Definition of atributes and methods of UnaryMasNode class
  \note    UnaryMasNode Class publicly inherits from NumericUnaryOperatorNode class
*/
class UnaryMasNode : public NumericUnaryOperatorNode
{

public:
	/*!		
	\brief Constructor of UnaryMasNode uses NumericUnaryOperatorNode's constructor as member initializer
	\param expression: pointer to ExpNode
	\post  A new UnaryMasNode is created with the parameter
*/
	UnaryMasNode(ExpNode *expression) : NumericUnaryOperatorNode(expression)
	{
		// empty
	}

	/*!
	\brief   Print the expression
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the expression
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   OperatorNode
  \brief   Definition of atributes and methods of OperatorNode class
  \note    OperatorNode Class publicly inherits from ExpNode class
  \warning Abstract class, because it does not redefine the print and getType methods of ExpNode
*/
class OperatorNode : public ExpNode
{
protected:
	ExpNode *_left;	//!< Left expression
	ExpNode *_right; //!< Right expression

public:
	/*!		
		\brief Constructor of OperatorNode links the node to its children,
		\param L: pointer to ExpNode
		\param R: pointer to ExpNode
		\post  A new OperatorNode is created with the parameters
	*/
	OperatorNode(ExpNode *L, ExpNode *R)
	{
		this->_left = L;
		this->_right = R;
	}
};

//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   NumericOperatorNode
  \brief   Definition of atributes and methods of NumericOperatorNode class
  \note    NumericOperatorNode Class publicly inherits from OperatorNode class
  \warning Abstract class, because it does not redefine the print method of ExpNode
*/
class NumericOperatorNode : public OperatorNode
{
public:
	/*!		
		\brief Constructor of NumericOperatorNode uses OperatorNode's constructor as members initializer
		\param L: pointer to ExpNode
		\param R: pointer to ExpNode
		\post  A new NumericOperatorNode is created with the parameters
	*/
	NumericOperatorNode(ExpNode *L, ExpNode *R) : OperatorNode(L, R)
	{
		//	Empty
	}

	/*!	
	\brief   Get the type of the children expressions
	\return  int
	\sa		 print()
	*/
	int getType();
};

//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   StringOperatorNode
  \brief   Definition of atributes and methods of StringOperatorNode class
  \note    StringOperatorNode Class publicly inherits from OperatorNode class
  \warning Abstract class, because it does not redefine the print method of ExpNode
*/
class StringOperatorNode : public OperatorNode
{
public:
	/*!		
		\brief Constructor of StringOperatorNode uses OperatorNode's constructor as members initializer
		\param L: pointer to ExpNode
		\param R: pointer to ExpNode
		\post  A new StringOperatorNode is created with the parameters
	*/
	StringOperatorNode(ExpNode *L, ExpNode *R) : OperatorNode(L, R)
	{
		//	Empty
	}

	/*!	
	\brief   Get the type of the children expressions
	\return  int
	\sa		 print()
	*/
	int getType();
};

//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   RelationalOperatorNode
  \brief   Definition of atributes and methods of RelationalOperatorNode class
  \note    RelationalOperatorNode Class publicly inherits from OperatorNode class
  \warning Abstract class, because it does not redefine the print method of ExpNode
*/
class RelationalOperatorNode : public OperatorNode
{
public:
	/*!		
	\brief Constructor of RelationalOperatorNode uses OperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new RelationalOperatorNode is created with the parameters
*/
	RelationalOperatorNode(ExpNode *L, ExpNode *R) : OperatorNode(L, R)
	{
		//	Empty
	}

	/*!	
	\brief   Get the type of the children expressions
	\return  int
	\sa		 print()
	*/
	int getType();
};

//////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   LogicalOperatorNode
  \brief   Definition of atributes and methods of LogicalOperatorNode class
  \note    NumericOperatorNode Class publicly inherits from OperatorNode class
  \warning Abstract class, because it does not redefine the print method of ExpNode
*/
class LogicalOperatorNode : public OperatorNode
{
public:
	/*!		
		\brief Constructor of LogicalOperatorNode uses OperatorNode's constructor as members initializer
		\param L: pointer to ExpNode
		\param R: pointer to ExpNode
		\post  A new NumericOperatorNode is created with the parameters
	*/
	LogicalOperatorNode(ExpNode *L, ExpNode *R) : OperatorNode(L, R)
	{
		//	Empty
	}

	/*!	
	\brief   Get the type of the children expressions
	\return  int
	\sa		 print()
	*/
	int getType();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   MasNode
  \brief   Definition of atributes and methods of MasNode class
  \note    MasNode Class publicly inherits from NumericOperatorNode class 
		   and adds its own print and evaluate functions
*/
class MasNode : public NumericOperatorNode
{
public:
	/*!		
	\brief Constructor of MasNode uses NumericOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new MasNode is created with the parameter
*/
	MasNode(ExpNode *L, ExpNode *R) : NumericOperatorNode(L, R)
	{
		// Empty
	}

	/*!
	\brief   Print the MasNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the MasNode
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   MenosNode
  \brief   Definition of atributes and methods of MenosNode class
  \note    MenosNode Class publicly inherits from NumericOperatorNode class 
		   and adds its own print and evaluate functions
*/
class MenosNode : public NumericOperatorNode
{
public:
	/*!		
	\brief Constructor of MenosNode uses NumericOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new MenosNode is created with the parameter
*/
	MenosNode(ExpNode *L, ExpNode *R) : NumericOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the MenosNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the MenosNode
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   MultiplicationNode
  \brief   Definition of atributes and methods of MultiplicationNode class
  \note    MultiplicationNode Class publicly inherits from NumericOperatorNode class 
		   and adds its own print and evaluate functions
*/
class MultiplicationNode : public NumericOperatorNode
{
public:
	/*!		
	\brief Constructor of MultiplicationNode uses NumericOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new MultiplicationNode is created with the parameter
*/
	MultiplicationNode(ExpNode *L, ExpNode *R) : NumericOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the MultiplicationNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the MultiplicationNode
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   DivisionNode
  \brief   Definition of atributes and methods of DivisionNode class
  \note    DivisionNode Class publicly inherits from NumericOperatorNode class 
		   and adds its own print and evaluate functions
*/
class DivisionNode : public NumericOperatorNode
{
public:
	/*!		
	\brief Constructor of DivisionNode uses NumericOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new DivisionNode is created with the parameter
*/
	DivisionNode(ExpNode *L, ExpNode *R) : NumericOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the DivisionNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the DivisionNode
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   DivisionEnteraNode
  \brief   Atributos y metodos para la division entera
  \note    DivisionEnteraNode Clase que hereda de NumericOperatorNode y añade su propio print y evaluate
*/
class DivisionEnteraNode : public NumericOperatorNode
{
public:
	/*!		
	\brief Constructor de DivisionEnteraNode usando el constructor de NumericOperatorNode
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  Crea un nuevo DivisionEnteraNode 
*/
	DivisionEnteraNode(ExpNode *L, ExpNode *R) : NumericOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the DivisionEnteraNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the DivisionEnteraNode
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   ModuloNode
  \brief   Definition of atributes and methods of ModuloNode class
  \note    ModuloNode Class publicly inherits from NumericOperatorNode class 
		   and adds its own print and evaluate functions
*/
class ModuloNode : public NumericOperatorNode
{
public:
	/*!		
	\brief Constructor of ModuloNode uses NumericOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new ModuloNode is created with the parameter
*/
	ModuloNode(ExpNode *L, ExpNode *R) : NumericOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the ModuloNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the ModuloNode
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   PotenciaNode
  \brief   Definition of atributes and methods of PotenciaNode class
  \note    PotenciaNode Class publicly inherits from NumericOperatorNode class 
		   and adds its own print and evaluate functions
*/
class PotenciaNode : public NumericOperatorNode
{
public:
	/*!		
	\brief Constructor of PotenciaNode uses NumericOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new PotenciaNode is created with the parameter
*/
	PotenciaNode(ExpNode *L, ExpNode *R) : NumericOperatorNode(L, R)
	{
		// Empty
	}

	/*!
	\brief   Print the PotenciaNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the PotenciaNode
	\return  double
	\sa		 print
*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   BuiltinFunctionNode
  \brief   Definition of atributes and methods of BuiltinFunctionNode class
  \note    BuiltinFunctionNode Class publicly inherits from ExpNode class 
*/
class BuiltinFunctionNode : public ExpNode
{
protected:
	std::string _id; //!< Name of the BuiltinFunctionNode

public:
	/*!		
	\brief Constructor of BuiltinFunctionNode
	\param id: string, name of the BuiltinFunction
	\post  A new BuiltinFunctionNode is created with the parameter
*/
	BuiltinFunctionNode(std::string id)
	{
		this->_id = id;
	}
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   BuiltinFunctionNode_0
  \brief   Definition of atributes and methods of BuiltinFunctionNode_0 class
  \note    BuiltinFunctionNode_0 Class publicly inherits from BuiltinFunctionNode class 
		   and adds its own print and evaluate functions
*/
class BuiltinFunctionNode_0 : public BuiltinFunctionNode
{
public:
	/*!		
	\brief Constructor of BuiltinFunctionNode_0 uses BuiltinFunctionNode's constructor as member initializer
	\param id: string, name of the BuiltinFunction
	\post  A new BuiltinFunctionNode_2 is created with the parameter
*/
	BuiltinFunctionNode_0(std::string id) : BuiltinFunctionNode(id)
	{
		//
	}

	/*!	
		\brief   Get the type of the child expression:
		\return  int
		\sa		 print
	*/
	int getType();

	/*!
		\brief   Print the BuiltinFunctionNode_0
		\return  void
		\sa		 evaluate()
	*/
	void print();

	/*!	
		\brief   Evaluate the BuiltinFunctionNode_0
		\return  double
		\sa		 print
	*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   BuiltinFunctionNode_1
  \brief   Definition of atributes and methods of BuiltinFunctionNode_1 class
  \note    BuiltinFunctionNode_1 Class publicly inherits from BuiltinFunctionNode class 
		   and adds its own print and evaluate functions
*/
class BuiltinFunctionNode_1 : public BuiltinFunctionNode
{
private:
	ExpNode *_exp; //!< Argument of the BuiltinFunctionNode_1

public:
	/*!		
	\brief Constructor of BuiltinFunctionNode_1 uses BuiltinFunctionNode's constructor as member initializer
	\param id: string, name of the BuiltinFunction
	\param expression: pointer to ExpNode, argument of the BuiltinFunctionNode_1
	\post  A new BuiltinFunctionNode_1 is created with the parameters
*/
	BuiltinFunctionNode_1(std::string id, ExpNode *expression) : BuiltinFunctionNode(id)
	{
		this->_exp = expression;
	}

	/*!	
		\brief   Get the type of the child expression:
		\return  int
		\sa		 print
	*/
	int getType();

	/*!
		\brief   Print the BuiltinFunctionNode_1
		\return  void
		\sa		 evaluate()
	*/
	void print();

	/*!	
		\brief   Evaluate the BuiltinFunctionNode_1
		\return  double
		\sa		 print
	*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   BuiltinFunctionNode_2
  \brief   Definition of atributes and methods of BuiltinFunctionNode_2 class 
  \note    BuiltinFunctionNode_2 Class publicly inherits from BuiltinFunctionNode class 
		   and adds its own print and evaluate functions
*/
class BuiltinFunctionNode_2 : public BuiltinFunctionNode
{
private:
	ExpNode *_exp1; //!< First argument of the BuiltinFunction_2
	ExpNode *_exp2; //!< Second argument of the BuiltinFunction_2

public:
	/*!		
		\brief Constructor of BuiltinFunctionNode_2 uses BuiltinFunctionNode's constructor as member initializer
		\param id: string, name of the BuiltinFunction_2
		\param expression1: pointer to ExpNode, first argument of the BuiltinFunctionNode
		\param expression2: pointer to ExpNode, second argument of the BuiltinFunctionNode
		\post  A new BuiltinFunctionNode_2 is created with the parameters
	*/
	BuiltinFunctionNode_2(std::string id, ExpNode *expression1, ExpNode *expression2) : BuiltinFunctionNode(id)
	{
		this->_exp1 = expression1;
		this->_exp2 = expression2;
	}

	/*!	
	\brief   Get the type of the children expressions
	\return  int
	\sa		 print
	*/
	int getType();

	/*!
		\brief   Print the BuiltinFunctionNode_2
		\return  void
		\sa		 evaluate()
	*/
	void print();

	/*!	
		\brief   Evaluate the BuiltinFunctionNode_2
		\return  double
		\sa		 print
	*/
	double evaluateNumber();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   MayorNode
  \brief   Definition of atributes and methods of MayorNode class
  \note    MayorNode Class publicly inherits from RelationalOperatorNode class 
		   and adds its own print and evaluate functions
*/
class MayorNode : public RelationalOperatorNode
{
public:
	/*!		
	\brief Constructor of MayorNode uses RelationalOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new MayorNode is created with the parameter
*/
	MayorNode(ExpNode *L, ExpNode *R) : RelationalOperatorNode(L, R)
	{
		// Empty
	}

	/*!
	\brief   Print the MayorNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the MayorNode
	\return  bool
	\sa		 print
*/
	bool evaluateBool();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   MayorOIgualNode
  \brief   Definition of atributes and methods of MayorOIgualNode class
  \note    MayorOIgualNode Class publicly inherits from RelationalOperatorNode class 
		   and adds its own print and evaluate functions
*/
class MayorOIgualNode : public RelationalOperatorNode
{
public:
	/*!		
	\brief Constructor of MayorOIgualNode uses RelationalOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new MayorOIgualNode is created with the parameter
*/
	MayorOIgualNode(ExpNode *L, ExpNode *R) : RelationalOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the MayorOIgualNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the MayorOIgualNode
	\return  bool
	\sa		 print()
*/
	bool evaluateBool();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   MenorNode
  \brief   Definition of atributes and methods of MenorNode class
  \note    MenorNode Class publicly inherits from RelationalOperatorNode class 
		   and adds its own print and evaluate functions
*/
class MenorNode : public RelationalOperatorNode
{
public:
	/*!		
	\brief Constructor of MenorNode uses RelationalOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new MenorNode is created with the parameter
*/
	MenorNode(ExpNode *L, ExpNode *R) : RelationalOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the MenorNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the MenorNode
	\return  bool
	\sa		 print()
*/
	bool evaluateBool();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   MenorOIgualNode
  \brief   Definition of atributes and methods of MenorOIgualNode class
  \note    MenorNode Class publicly inherits from RelationalOperatorNode class 
		   and adds its own print and evaluate functions
*/
class MenorOIgualNode : public RelationalOperatorNode
{
public:
	/*!		
	\brief Constructor of MenorOIgualNode uses RelationalOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new MenorOIgualNode is created with the parameter
*/
	MenorOIgualNode(ExpNode *L, ExpNode *R) : RelationalOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the MenorOIgualNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the MenorOIgualNode
	\return  bool
	\sa		 print()
*/
	bool evaluateBool();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   IgualNode
  \brief   Definition of atributes and methods of IgualNode class
  \note    IgualNode Class publicly inherits from RelationalOperatorNode class 
		   and adds its own print and evaluate functions
*/
class IgualNode : public RelationalOperatorNode
{
public:
	/*!		
	\brief Constructor of IgualNode uses RelationalOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new IgualNode is created with the parameter
*/
	IgualNode(ExpNode *L, ExpNode *R) : RelationalOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the IgualNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the IgualNode
	\return  bool
	\sa		 print()
*/
	bool evaluateBool();
	;
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   NoIgualNode
  \brief   Definition of atributes and methods of NoIgualNode class
  \note    NoIgualNode Class publicly inherits from RelationalOperatorNode class 
		   and adds its own print and evaluate functions
*/
class NoIgualNode : public RelationalOperatorNode
{
public:
	/*!		
	\brief Constructor of NoIgualNode uses RelationalOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new NoIgualNode is created with the parameter
*/
	NoIgualNode(ExpNode *L, ExpNode *R) : RelationalOperatorNode(L, R)
	{
		// Empty
	}

	/*!
	\brief   Print the NoIgualNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the NoIgualNode
	\return  bool
	\sa		 print()
*/
	bool evaluateBool();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   AndNode
  \brief   Definition of atributes and methods of AndNode class
  \note    AndNode Class publicly inherits from LogicalOperatorNode class 
		   and adds its own print and evaluate functions
*/
class AndNode : public LogicalOperatorNode
{
public:
	/*!		
	\brief Constructor of AndNode uses LogicalOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new AndNode is created with the parameter
*/
	AndNode(ExpNode *L, ExpNode *R) : LogicalOperatorNode(L, R)
	{
		// Empty
	}

	/*!
	\brief   Print the AndNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the AndNode
	\return  bool
	\sa		 print()
*/
	bool evaluateBool();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   OrNode
  \brief   Definition of atributes and methods of OrNode class
  \note    OrNode Class publicly inherits from LogicalOperatorNode class 
		   and adds its own print and evaluate functions
*/
class OrNode : public LogicalOperatorNode
{
public:
	/*!		
	\brief Constructor of AndNode uses LogicalOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new AndNode is created with the parameter
*/
	OrNode(ExpNode *L, ExpNode *R) : LogicalOperatorNode(L, R)
	{
		// Empty
	}

	/*!
	\brief   Print the OrNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the OrNode
	\return  bool
	\sa		 print()
*/
	bool evaluateBool();
};

//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

/*!	
  \class   NotNode
  \brief   Definition of atributes and methods of UnaryPlusNode class
  \note    NotNode Class publicly inherits from LogicalUnaryOperatorNode class
*/
class NotNode : public LogicalUnaryOperatorNode
{

public:
	/*!		
	\brief Constructor of NotNode uses LogicalUnaryOperatorNode's constructor as member initializer
	\param expression: pointer to ExpNode
	\post  A new NotNode is created with the parameter
*/
	NotNode(ExpNode *expression) : LogicalUnaryOperatorNode(expression)
	{
		// empty
	}

	/*!
	\brief   Print the NotNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the NotNode
	\return  bool
	\sa		 print()
*/
	bool evaluateBool();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   ConcatenationNode
  \brief   Definition of atributes and methods of ConcatenationNode class
  \note    ConcatenationNode Class publicly inherits from StringOperatorNode class 
		   and adds its own print and evaluate functions
*/
class ConcatenationNode : public StringOperatorNode
{
public:
	/*!		
	\brief Constructor of ConcatenationNode uses StringOperatorNode's constructor as members initializer
	\param L: pointer to ExpNode
	\param R: pointer to ExpNode
	\post  A new ConcatenationNode is created with the parameter
*/
	ConcatenationNode(ExpNode *L, ExpNode *R) : StringOperatorNode(L, R)
	{
		// Empty
	}
	/*!
	\brief   Print the ConcatenationNode
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the ConcatenationNode
	\return  std::string
	\sa		 print
*/
	std::string evaluateCadena();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   Statement
  \brief   Definition of atributes and methods of Statement class
  \warning Abstract class
*/

class Statement
{
public:
	/*!	
	\brief   Print the Statement
	\note    Virtual function: can be redefined in the heir classes
	\return  double
	\sa		 print
*/

	virtual void print() {}

	/*!	
	\brief   Evaluate the Statement
	\warning Pure virtual function: must be redefined in the heir classes
	\return  double
	\sa		 print
*/
	virtual void evaluate() = 0;
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   AsignacionStmt
  \brief   Definition of atributes and methods of AsignacionStmt class
  \note    AsignacionStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class AsignacionStmt : public Statement
{
private:
	std::string _id; //!< Name of the variable of the assignment statement
	ExpNode *_exp;	 //!< Expresssion the assignment statement

	AsignacionStmt *_asgn; //!< Allow multiple assigment -> a = b = 2

public:
	/*!		
	\brief Constructor of AsignacionStmt 
	\param id: string, variable of the AsignacionStmt
	\param expression: pointer to ExpNode
	\post  A new AsignacionStmt is created with the parameters
*/
	AsignacionStmt(std::string id, ExpNode *expression) : _id(id), _exp(expression)
	{
		this->_asgn = NULL;
	}

	/*!		
	\brief Constructor of AsignacionStmt 
	\param id: string, variable of the AsignacionStmt
	\param asgn: pointer to AsignacionStmt
	\post  A new AsignacionStmt is created with the parameters
	\note  Allow multiple assigment -> a = b = 2 
*/

	AsignacionStmt(std::string id, AsignacionStmt *asgn) : _id(id), _asgn(asgn)
	{
		this->_exp = NULL;
	}

	/*!
	\brief   Print the AsignacionStmt
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the AsignacionStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   BorrarStmt
  \brief   Definition of atributes and methods of BorrarStmt class
  \note    BorrarStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
  \warning  In this class, print and evaluate functions have the same meaning.
*/
class BorrarStmt : public Statement
{

public:
	/*!		
	\brief Constructor of BorrarStmt 
	\post  A new BorrarStmt is created 
*/
	BorrarStmt()
	{
	}

	/*!
	\brief   Print the BorrarStmt
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the BorrarStmt
	\return  double
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   LugarStmt
  \brief   Definition of atributes and methods of LugarStmt class
  \note    LugarStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
  \warning  In this class, print and evaluate functions have the same meaning.
*/
class LugarStmt : public Statement
{
private:
	ExpNode *_fila, *_columna;

public:
	/*!		
	\brief Constructor of LugarStmt 
	\post  A new LugarStmt is created 
*/
	LugarStmt(ExpNode *A, ExpNode *B)
	{
		this->_fila = A;
		this->_columna = B;
	}

	/*!
	\brief   Print the LugarStmt
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the LugarStmt
	\return  double
	\sa		 print
*/
	void evaluate();
};
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   PrintStmt
  \brief   Definition of atributes and methods of PrintStmt class
  \note    PrintStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
  \warning  In this class, print and evaluate functions have the same meaning.
*/
class PrintStmt : public Statement
{
private:
	ExpNode *_exp; //!< Expresssion the print statement

public:
	/*!		
	\brief Constructor of PrintStmt 
	\param expression: pointer to ExpNode
	\post  A new PrintStmt is created with the parameter
*/
	PrintStmt(ExpNode *expression)
	{
		this->_exp = expression;
	}

	/*!
	\brief   Print the PrintStmt
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the PrintStmt
	\return  double
	\sa		 print
*/
	void evaluate();
};
///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   PrintStmt
  \brief   Definition of atributes and methods of PrintStmt class
  \note    PrintStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
  \warning  In this class, print and evaluate functions have the same meaning.
*/
class PrintCadenaStmt : public Statement
{
private:
	ExpNode *_exp; //!< Expresssion the print statement

public:
	/*!		
	\brief Constructor of PrintStmt 
	\param expression: pointer to ExpNode
	\post  A new PrintStmt is created with the parameter
*/
	PrintCadenaStmt(ExpNode *expression)
	{
		this->_exp = expression;
	}

	/*!
	\brief   Print the PrintStmt
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the PrintStmt
	\return  double
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   ReadStmt
  \brief   Definition of atributes and methods of ReadStmt class
  \note    ReadStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class ReadStmt : public Statement
{
private:
	std::string _id; //!< Name of the ReadStmt

public:
	/*!		
	\brief Constructor of ReadStmt
	\param id: string, name of the variable of the ReadStmt
	\post  A new ReadStmt is created with the parameter
*/
	ReadStmt(std::string id)
	{
		this->_id = id;
	}

	/*!
	\brief   Print the ReadStmt
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the ReadStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   ReadCadenaStmt
  \brief   Definition of atributes and methods of ReadCadenaStmt class
  \note    ReadCadenaStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class ReadCadenaStmt : public Statement
{
private:
	std::string _id; //!< Name of the ReadCadenaStmt

public:
	/*!		
	\brief Constructor of ReadCadenaStmt
	\param id: string, name of the variable of the ReadCadenaStmt
	\post  A new ReadCadenaStmt is created with the parameter
*/
	ReadCadenaStmt(std::string id)
	{
		this->_id = id;
	}

	/*!
	\brief   Print the ReadCadenaStmt
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the ReadCadenaStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   EmptyStmt
  \brief   Definition of atributes and methods of EmptyStmt class
  \note    EmptyStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class EmptyStmt : public Statement
{
	// No attributes

public:
	/*!		
	\brief Constructor of  EmptyStmt
	\post  A new EmptyStmt is created 
*/
	EmptyStmt()
	{
		// Empty
	}

	/*!
	\brief   Print the EmptyStmt
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   Evaluate the EmptyStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
// NEW in example 17

/*!	
  \class   SiStmt
  \brief   Definition of atributes and methods of SiStmt class
  \note    SiStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class SiStmt : public Statement
{
private:
	ExpNode *_cond;												 //!< Condicion of the if statement
	std::list<Statement *> *_consecuentes; //!< Statement of the consequent
	std::list<Statement *> *_alternativas; //!< Statement of the alternative

public:
	/*!		
	\brief Constructor of Single SiStmt (without alternative)
	\param condition: ExpNode of the condition
	\param statement1: Statement of the consequent
	\post  A new SiStmt is created with the parameters
*/
	SiStmt(ExpNode *condition, std::list<Statement *> *statement1)
	{
		this->_cond = condition;
		this->_consecuentes = statement1;
		this->_alternativas = NULL;
	}

	/*!		
	\brief Constructor of Compound SiStmt (with alternative)
	\param condition: ExpNode of the condition
	\param statement1: Statement of the consequent
	\param statement2: Statement of the alternative
	\post  A new SiStmt is created with the parameters
*/
	SiStmt(ExpNode *condition, std::list<Statement *> *statement1, std::list<Statement *> *statement2)
	{
		this->_cond = condition;
		this->_consecuentes = statement1;
		this->_alternativas = statement2;
	}

	/*!
	\brief   Print the SiStmt
	\return  void
	\sa		 evaluate
*/
	void print();

	/*!	
	\brief   Evaluate the SiStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
// NEW in example 17

/*!	
  \class   MientrasStmt
  \brief   Definition of atributes and methods of MientrasStmt class
  \note    MientrasStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class MientrasStmt : public Statement
{
private:
	ExpNode *_cond;												 //!< Condicion of the while statement
	std::list<Statement *> *_consecuentes; //!< Statement of the body of the while loop

public:
	/*!		
	\brief Constructor of  MientrasStmt
	\param condition: ExpNode of the condition
	\param statement: Statement of the body of the loop 
	\post  A new MientrasStmt is created with the parameters
*/
	MientrasStmt(ExpNode *condition, std::list<Statement *> *statement)
	{
		this->_cond = condition;
		this->_consecuentes = statement;
	}

	/*!
	\brief   Print the MientrasStmt
	\return  void
	\sa		 evaluate
*/
	void print();

	/*!	
	\brief   Evaluate the MientrasStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   RepetirStmt
  \brief   Definition of atributes and methods of RepetirStmt class
  \note    RepetirStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class RepetirStmt : public Statement
{
private:
	ExpNode *_cond;												 //!< Condicion of the  do_while statement
	std::list<Statement *> *_consecuentes; //!< Statement of the body of the do_while loop

public:
	/*!		
	\brief Constructor of  RepetirStmt
	\param condition: ExpNode of the condition
	\param statement: Statement of the body of the loop 
	\post  A new RepetirStmt is created with the parameters
*/
	RepetirStmt(std::list<Statement *> *statement, ExpNode *condition)
	{
		this->_cond = condition;
		this->_consecuentes = statement;
	}

	/*!
	\brief   Print the RepetirStmt
	\return  void
	\sa		 evaluate
*/
	void print();

	/*!	
	\brief   Evaluate the RepetirStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   ParaStmt
  \brief   Definition of atributes and methods of ParaStmt class
  \note    ParaStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class ParaStmt : public Statement
{
private:
	std::string _id;											//!< Id of the condition
	ExpNode *_desde;											//!< Iniciacion of the for statement
	ExpNode *_hasta;											//!< Condicion of the for statement
	ExpNode *_paso;												//!< Condicion of the for statement
	std::list<Statement *> *_consecuente; //!< Statement of the body of the for loop
																				/*!
	\brief   Evalua la funcion paso
	\return  void
*/
	void evaluatePaso();

public:
	/*!		
	\brief Constructor of  ParaStmt
	\param id: Id of the condition
	\param desde: Iniciacion of the loop 
	\param hasta: Condicion of the loop 
	\param statement: Statement of the body of the loop 
	\post  A new ParaStmt is created with the parameters
*/
	ParaStmt(std::string id, ExpNode *desde, ExpNode *hasta, std::list<Statement *> *statement, ExpNode *paso = NULL)
	{
		this->_id = id;
		this->_desde = desde;
		this->_hasta = hasta;
		this->_paso = paso;
		this->_consecuente = statement;
	}

	/*!
	\brief   Print the ParaStmt
	\return  void
	\sa		 evaluate
*/
	void print();

	/*!	
	\brief   Evaluate the ParaStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
// NEW in example 17

/*!	
  \class   BlockStmt
  \brief   Definition of atributes and methods of BlockStmt class
  \note    BlockStmt Class publicly inherits from Statement class 
		   and adds its own print and evaluate functions
*/
class BlockStmt : public Statement
{
private:
	std::list<Statement *> *_stmts; //!< List of statements

public:
	/*!		
	\brief Constructor of  MientrasStmt
	\param stmtList: list of Statement
	\post  A new BlockStmt is created with the parameters
*/
	BlockStmt(std::list<Statement *> *stmtList) : _stmts(stmtList)
	{
		// Empty
	}

	/*!
	\brief   Print the BlockStmt
	\return  void
	\sa		 evaluate
*/
	void print();

	/*!	
	\brief   Evaluate the BlockStmt
	\return  void
	\sa		 print
*/
	void evaluate();
};

///////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

/*!	
  \class   AST
  \brief   Definition of atributes and methods of AST class
*/
class AST
{
private:
	std::list<Statement *> *stmts; //!< List of statements

public:
	/*!		
	\brief Constructor of PrintStmt 
	\param stmtList: pointer to a list of pointers to Statement
	\post  A new PrintStmt is created with the parameter
*/
	AST(std::list<Statement *> *stmtList) : stmts(stmtList)
	{
		// Empty
	}

	/*!
	\brief   print the AST
	\return  void
	\sa		 evaluate()
*/
	void print();

	/*!	
	\brief   evaluate the AST
	\return  double
	\sa		 print
*/
	void evaluate();
};

// End of name space lp
} // namespace lp

// End of _AST_HPP_
#endif
