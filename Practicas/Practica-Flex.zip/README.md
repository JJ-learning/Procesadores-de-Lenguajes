# How to run the programs
Build the program using the following script
> ./build.sh eje*.l

Depends on the exercise, the user will have to run the program like this:
1. Exercise 1:
> ./built/a.out entrada.txt output.txt

2. Exercise 2:
> ./built/a.out fichero.txt old-word new-word output.txt

4. Exercise 4:
> ./built/a.out logins.txt user [day]

5. Exercise 5:
> ./built/a.out key-word