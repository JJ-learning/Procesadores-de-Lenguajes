#!/bin/bash
reset
rm -rf built

mkdir built
cd built

flex ../$1
gcc lex.yy.c -lfl
echo "Compilation done."

