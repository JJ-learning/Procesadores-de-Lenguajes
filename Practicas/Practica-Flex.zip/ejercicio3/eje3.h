#define BEGINING 257
#define END 262
#define READ 263
#define WRITE 264
#define IF 265
#define THEN 266
#define IF_NOT 267
#define END_IF 268
#define WHILE 269
#define DO 270
#define END_WHILE 271
#define REPEAT 272
#define UNTIL_THAT 273
#define FOR 274
#define FROM 275
#define UNTIL 276
#define STEP 277
#define END_FOR 278

#define NUMBER 279
#define IDENTIFIER 280

#define ASSIGN 281
#define SUM 282
#define MINUS 283
#define PRODUCT 284
#define DIVISION 285
#define __MOD 286
#define __O 287
#define __Y 288
#define __NO 289
#define ELEVATED 290
#define CONCATENATION 291
#define LESS 292
#define LESS_EQ 293
#define GREATER 294
#define GREATER_EQ 295
#define EQUAL 296
#define NOT_EQUAL 297
#define END_SENTENCE 298
#define R_PARENTHESIS 299
#define L_PARENTHESIS 300

#define COMMENT 301
#define STRING 302



