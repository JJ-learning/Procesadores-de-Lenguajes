#!/bin/bash
reset
rm -rf built

mkdir built
cd built

flex ../$1
gcc lex.yy.c -lfl 
echo "Compilation done."
echo "Running program..."
if [ -z "$3" ];
then
    ./a.out ../$2 >> ../salida.txt
    echo "Program finished and saved within salida.txt"
else
    ./a.out ../$2 >> ../$3
    echo "Program finished and saved within $3"
fi



