# Exercise 3
In order to use the program, type in the terminal:
> ./build.sh eje3.l Newton.txt [output.txt]